function limpa()
    {
        document.getElementById('calculo').innerHTML = "";
    }

function inclui(num)
    {
        var numero = document.getElementById('calculo').innerHTML;
        document.getElementById('calculo').innerHTML = numero + num;
    }

function calcular()
    {
        var calculo = document.getElementById('calculo').innerHTML;
        if(calculo)
        {
            document.getElementById('calculo').innerHTML = eval(calculo);
        }
    }
//</script>